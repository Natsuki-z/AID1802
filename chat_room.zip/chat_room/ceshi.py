# 开发时间： 2022/9/30 10:31
str01 = "1 2 3 4"
str02 = "123 4"
list01 = str01.split(" ", 2)
list02 = str02.split(" ", 3)
print(list01)
print(list02)
if " " in str02:
    print("have")
