# 开发时间： 2022/9/30 8:35
"""
chat room 客户端
发送请求，展示结果
"""

from socket import *
import os
import sys

# 服务器地址
ADDR = ("127.0.0.1", 9999)


# 进入聊天室
def join_chat_room(s):
    while True:
        name = input("User name:")
        msg = "J-" + name
        s.sendto(msg.encode(), ADDR)
        # 接收反馈
        data, addr = s.recvfrom(128)
        if data.decode() == "OK":
            print("Success to join")
            return name
        else:
            print(data.decode())


# 发送消息
def send_msg(s, name):
    while True:
        try:
            matter = input(">>")
        except KeyboardInterrupt:
            matter = "quit"
        if matter.strip() == "quit":
            msg = "Q-" + name
            s.sendto(msg.encode(), ADDR)
            sys.exit("Quit chat room")
        else:
            msg = "C-%s-%s" % (name, matter)
            s.sendto(msg.encode(), ADDR)


# 接收消息
def recv_msg(s):
    while True:
        try:
            data, addr = s.recvfrom(4096)
        except KeyboardInterrupt:
            sys.exit()
        # 从服务器收到Exit退出
        if data.decode() == "Exit":
            sys.exit()
        print(data.decode() + "\n发言", end="")


# 聊天
def chat(s, name):
    pid = os.fork()
    if pid < 0:
        sys.exit("Error!")
    elif pid == 0:
        send_msg(s, name)  # 子进程负责发送消息
    else:
        recv_msg(s)  # 父进程负责接收消息


# 客户端启动函数
def main():
    sockfd = socket(AF_INET, SOCK_DGRAM)
    name = join_chat_room(sockfd)
    chat(sockfd, name)
    # cmd = input(">>")
    # sockfd.sendto(cmd.encode(), ADDR)


main()
