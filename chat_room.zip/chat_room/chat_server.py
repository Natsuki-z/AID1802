# 开发时间： 2022/9/29 21:10
"""
chat room
env:python3.8
socked udp & fork
"""

from socket import *
import os
import sys

"""
global variable:很多封装模块都要用或者有一定的固定含义
"""

# 服务器地址
ADDR = ("127.0.0.1", 9999)

# 储存用户 {name:address}
user = {}


# 加入请求
def join_request(s, name, addr):
    if name in user or "管理员" in name:
        s.sendto(b"The user have existed", addr)
        return
    s.sendto(b"OK", addr)  # 可以进入聊天室
    # 通知其他人
    msg = "\nWelcome '%s' to join" % name
    for key in user:
        s.sendto(msg.encode(), user[key])
    user[name] = addr  # 插入字典


# 聊天
def chat(s, name, matter):
    msg = "\n%s: %s" % (name, matter)
    for key in user:
        if key != name:
            s.sendto(msg.encode(), user[key])


# 退出
def do_quit(s, name):
    msg = b"Exit"
    s.sendto(msg, user[name])
    del user[name]  # 删除用户
    msg = "\n%s quits the chat room" % name
    for key in user:
        s.sendto(msg.encode(), user[key])


# 处理请求
def do_request(s):
    while True:
        data, addr = s.recvfrom(1024)
        # msg = data.decode().split(" ")
        msg = data.decode().split("-", 2)
        # 根据不同的请求类型具体执行不同的事情
        # L 进入  C 聊天  Q 退出
        if msg[0] == "J":
            join_request(s, msg[1], addr)
        if msg[0] == "C":
            # text = " ".join(msg[2:])
            # chat(s, msg[1], text)
            chat(s, msg[1], msg[2])
        if msg[0] == "Q":
            do_quit(s, msg[1])


# 搭建网络
def main():
    # udp服务端
    sockfd = socket(AF_INET, SOCK_DGRAM)
    sockfd.bind(ADDR)

    pid = os.fork()
    if pid == 0:
        while True:
            msg = input("管理员消息：")
            msg = "C-管理员-"+msg
            sockfd.sendto(msg, ADDR)
    else:
        # 请求处理函数
        do_request(sockfd)


main()
